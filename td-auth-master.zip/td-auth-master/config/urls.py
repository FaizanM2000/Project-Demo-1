from django.contrib import admin
from django.urls import path, include
from django.views.generic.base import TemplateView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('accounts.urls')), # new
    path('accounts/', include('django.contrib.auth.urls')),
    path('accounts/', include('allauth.urls')),
    path('', TemplateView.as_view(template_name='home.html'), name='home'),
    path('pricing/', TemplateView.as_view(template_name='pricing.html'), name='pricing'),
    path('contact/', TemplateView.as_view(template_name='contact.html'), name='contact us'),
]
